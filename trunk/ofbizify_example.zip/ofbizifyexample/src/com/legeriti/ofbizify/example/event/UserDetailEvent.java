package com.legeriti.ofbizify.example.event;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ofbiz.base.util.UtilHttp;
import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;

import com.legeriti.ofbizify.gwt.gwtrpc.util.GwtRpcPayloadUtil;


public class UserDetailEvent {

    public static final String module = UserDetailEvent.class.getName();

    public static String getUserDetails(HttpServletRequest request, HttpServletResponse response) {

    	System.err.println("####### GetUserDetails (JavaEvent) invoked ##############");
    	
    	List<GenericValue> users = null;
    	
    	Delegator delegator = (Delegator) request.getAttribute("delegator");
    	Map<String, Object> requestParams = UtilHttp.getParameterMap(request);
        Map<String, Object> attributeParams = UtilHttp.getAttributeMap(request);
        
        System.err.println("delegator -> " + delegator);
        System.err.println("requestParams -> " + requestParams);
        System.err.println("attributeParams -> " + attributeParams);

        try {

        	//fields = new HashSet(["userId", "firstName", "lastName", "address", "lastUpdatedStamp"]);
        	//fields
        	users = delegator.findList("OfbizifyExampleUsers", null, null, null, null, true );
        	System.err.println("users -> " + users + "\n");

        } catch(GenericEntityException gee) {
            gee.printStackTrace();
        }

        Map<String, Object> result = GwtRpcPayloadUtil.returnSuccessWithPayload(users);
        request.setAttribute("result", result);

        return "success";
    }

    public static String createUserDetails(HttpServletRequest request, HttpServletResponse response) {
    	
    	System.err.println("####### createUserDetails (JavaEvent) invoked ##############");

    	Delegator delegator = (Delegator) request.getAttribute("delegator");
    	Map<String, Object> requestParams = UtilHttp.getParameterMap(request);
        Map<String, Object> attributeParams = UtilHttp.getAttributeMap(request);
        
        System.err.println("delegator -> " + delegator);
        System.err.println("requestParams -> " + requestParams);
        System.err.println("attributeParams -> " + attributeParams);

        String firstName = (String) attributeParams.get("firstName"); 
        String lastName = (String) attributeParams.get("lastName");
        String address = (String) attributeParams.get("address");

        String returnValue = null;
        
        try
       	{
        	String userId = null;
        	userId = delegator.getNextSeqId("OfbizifyExampleUsers");
        	
        	if(UtilValidate.isNotEmpty(userId)) {

        		GenericValue user = delegator.makeValue("OfbizifyExampleUsers", 
        	    		  UtilMisc.toMap("userId", userId, 
        	    				  		"firstName", firstName, 
        	    				  		"lastName", lastName,
        	    				        "address", address
        	    		  ));
        		
        		List toBeStored = new LinkedList();
        		toBeStored.add(user);
        		
        		delegator.storeAll(toBeStored);
        		
        		returnValue = "success";
        	}
        	
        }
        catch (IllegalArgumentException e) {
        	returnValue = "error";
          e.printStackTrace();
        }
        catch (GenericEntityException gee)
        {
        	returnValue = "error";
            gee.printStackTrace();
        }
        
        Map<String, Object> result = null;
        
        if("success".equals(returnValue)) {
        	result = GwtRpcPayloadUtil.returnSuccess();	
        } else if("error".equals(returnValue)) {
        	result = GwtRpcPayloadUtil.returnError("Exception occured");
        }

        request.setAttribute("result", result);

        return returnValue;
    }
}
