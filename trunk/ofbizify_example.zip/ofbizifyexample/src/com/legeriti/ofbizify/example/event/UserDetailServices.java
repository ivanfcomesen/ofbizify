package com.legeriti.ofbizify.example.event;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.service.DispatchContext;

import com.legeriti.ofbizify.gwt.gwtrpc.util.GwtRpcPayloadUtil;


public class UserDetailServices {

    public static final String module = UserDetailServices.class.getName();

    public static Map getUserDetails(DispatchContext dctx, Map context) {
    	
    	System.err.println("####### getUserDetails (Service) invoked ##############");

    	List<GenericValue> users = null;

    	Delegator delegator = dctx.getDelegator();
        System.err.println("delegator -> " + delegator);

        try {

        	users = delegator.findList("OfbizifyExampleUsers", null, null, null, null, true );
        	System.err.println("users -> " + users + "\n");

        } catch(GenericEntityException gee) {
            gee.printStackTrace();
        }
        
        Map<String, Object> result = GwtRpcPayloadUtil.returnSuccessWithPayload(users);

        Map<String, Object> returnMap = new HashMap<String, Object>();
        returnMap.put("result", result);

        return returnMap;
    }

    public static Map createUserDetails(DispatchContext dctx, Map context) {
    	
    	System.err.println("####### createUserDetails (Service) invoked ##############");
    	
    	Map<String, Object> result = null;

    	Delegator delegator = dctx.getDelegator();
    	System.err.println("delegator -> " + delegator);

    	String firstName = (String) context.get("firstName");
        String lastName = (String) context.get("lastName");
        String address = (String) context.get("address");

        System.err.println("firstName -> " + firstName);
        System.err.println("lastName -> " + lastName);
        System.err.println("address -> " + address);
        
        try
       	{
        	String userId = null;
        	userId = delegator.getNextSeqId("OfbizifyExampleUsers");
        	
        	if(UtilValidate.isNotEmpty(userId)) {

        		GenericValue user = delegator.makeValue("OfbizifyExampleUsers", 
        	    		  UtilMisc.toMap("userId", userId, 
        	    				  		"firstName", firstName, 
        	    				  		"lastName", lastName,
        	    				        "address", address
        	    		  ));
        		
        		List toBeStored = new LinkedList();
        		toBeStored.add(user);
        		
        		delegator.storeAll(toBeStored);
        		
        		result = GwtRpcPayloadUtil.returnSuccess();	
        	}
        	
        }
        catch (IllegalArgumentException e) {
        	result = GwtRpcPayloadUtil.returnError("Exception occured");
        	e.printStackTrace();
        }
        catch (GenericEntityException gee) {
        	result = GwtRpcPayloadUtil.returnError("Exception occured");
            gee.printStackTrace();
        }
        
        Map<String, Object> returnMap = new HashMap<String, Object>();
        
        returnMap.put("result", result);
        
        return returnMap;
    }
}