import org.ofbiz.entity.*;
import org.ofbiz.common.*;
import org.ofbiz.base.util.*;
import java.util.*;
import javolution.util.*;
import org.ofbiz.service.*;
import org.ofbiz.base.util.*;
import com.legeriti.ofbizify.gwt.gwtrpc.util.GwtRpcPayloadUtil;

System.err.println("####### CreateUserDetails.groovy invoked ##############");
System.err.println("parameters -> " + parameters);

String firstName = parameters.firstName; 
String lastName = parameters.lastName;
String address = parameters.address;

String userId = null;

String returnValue = null;

try
{
	userId = delegator.getNextSeqId("OfbizifyExampleUsers");
	
	if(UtilValidate.isNotEmpty(userId)) {

		GenericValue user = delegator.makeValue("OfbizifyExampleUsers", 
	    		  UtilMisc.toMap("userId", userId, 
	    				  		"firstName", firstName, 
	    				  		"lastName", lastName,
	    				        "address", address
	    		  ));
		
		List toBeStored = new LinkedList();
		toBeStored.add(user);
		
		delegator.storeAll(toBeStored);
		
		returnValue = "success";
	}
}
catch (IllegalArgumentException e) {
  returnValue = "error";
  e.printStackTrace();
}
catch (GenericEntityException gee)
{
	returnValue = "error";
    gee.printStackTrace();
}

return GwtRpcPayloadUtil.returnSuccess();