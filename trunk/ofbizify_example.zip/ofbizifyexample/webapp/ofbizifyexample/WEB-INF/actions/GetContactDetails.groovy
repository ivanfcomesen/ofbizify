import org.ofbiz.entity.*;
import org.ofbiz.common.*;
import java.util.*;
import javolution.util.*;
import org.ofbiz.service.*;
import org.ofbiz.base.util.*;

Map<String, String> contactDetails = FastMap.newInstance();

try {

	//GenericValue userLogin = context.userLogin;

	//not getting the userLogin from context as user is not logged in
	GenericValue userLogin = delegator.findOne("UserLogin", UtilMisc.toMap("userLoginId", "DemoCustomer"), false);

	String partyId = userLogin.partyId;

	//start - get personal details
	String firstName = null;
	Map resultGetPerson = dispatcher.runSync("getPerson", UtilMisc.toMap("partyId", partyId));
	if(!ServiceUtil.isError(resultGetPerson)) {
		GenericValue person = (GenericValue)resultGetPerson.get("lookupPerson");
        firstName = person.getString("firstName");
	}
	//end - get personal details

	//start - email
	String emailId = null;
	String emailContactMechId = null;
	
    Map resultGetPartyEmail = dispatcher.runSync("getPartyEmail", UtilMisc.toMap("partyId", partyId, "userLogin", userLogin));
    if(!ServiceUtil.isError(resultGetPartyEmail)) {
    	emailId = resultGetPartyEmail.get("emailAddress");
    	emailContactMechId = resultGetPartyEmail.get("contactMechId");
    }
    //end - email

    //start - address
    String addressContactMechId = null;
    String stateProvinceGeoId = null;
    String stateProvinceGeoName = null;
    String countryGeoId = null;
    String countryGeoName = null;
    Map postalAddress = dispatcher.runSync("getPartyPostalAddress", 
            					UtilMisc.toMap("partyId", partyId, "contactMechPurposeTypeId", "GENERAL_LOCATION", "userLogin", userLogin));
    if(!ServiceUtil.isError(postalAddress)) {

    	addressContactMechId = postalAddress.get("contactMechId");
    	stateProvinceGeoId = postalAddress.get("stateProvinceGeoId");
    	countryGeoId = postalAddress.get("countryGeoId");
    }

    if(UtilValidate.isNotEmpty(countryGeoId)) {

    	countryGeoValue = delegator.findByPrimaryKeyCache("Geo", [geoId : countryGeoId]);
        if (countryGeoValue) {
        	countryGeoName = countryGeoValue.geoName;
        }
    }
    
    if(UtilValidate.isNotEmpty(stateProvinceGeoId)) {
    	
    	stateGeoValue = delegator.findByPrimaryKeyCache("Geo", [geoId : stateProvinceGeoId]);
        if (stateGeoValue) {
        	stateProvinceGeoName = stateGeoValue.geoName;
        }
    }
    //end - address
    
    //start - phone
    String phoneContactMechId = null;
    String phoneNo = null;
    Map primaryPhone = dispatcher.runSync("getPartyTelephone", 
            					UtilMisc.toMap("partyId", partyId, "contactMechPurposeTypeId", "PRIMARY_PHONE", "userLogin", userLogin));

    if(!ServiceUtil.isError(primaryPhone)) {

    	phoneContactMechId = primaryPhone.get("contactMechId");
    	
    	//String countryCode = primaryPhone.get("countryCode");
    	//String areaCode = primaryPhone.get("areaCode");
    	String contactNumber = primaryPhone.get("contactNumber");

    	//phoneNo = countryCode + "-" + areaCode + "-" + contactNumber;
    	phoneNo = contactNumber;
    }

    String mobileContactMechId = null
    String mobileNo = null;
    Map mobilePhone = dispatcher.runSync("getPartyTelephone", 
            					UtilMisc.toMap("partyId", partyId, "contactMechPurposeTypeId", "PHONE_MOBILE", "userLogin", userLogin));

    if(!ServiceUtil.isError(mobilePhone)) {
    	
    	mobileContactMechId = mobilePhone.get("contactMechId");
    	
    	//String countryCode = mobilePhone.get("countryCode");
    	//String areaCode = mobilePhone.get("areaCode");
    	String contactNumber = mobilePhone.get("contactNumber");

    	//mobileNo = countryCode + "-" + areaCode + "-" + contactNumber;
    	mobileNo = contactNumber;
    }
    //end - phone

    contactDetails.put("partyId", partyId);
	contactDetails.put("firstName", firstName);
	
	contactDetails.put("emailContactMechId", emailContactMechId);
	contactDetails.put("emailId", emailId);
	
	contactDetails.put("addressContactMechId", addressContactMechId); 
	contactDetails.put("stateProvinceGeoId", stateProvinceGeoId);
	contactDetails.put("stateProvinceGeoName", stateProvinceGeoName); 
	contactDetails.put("countryGeoId", countryGeoId);
	contactDetails.put("countryGeoName", countryGeoName);
	
	contactDetails.put("phoneContactMechId", phoneContactMechId);
	contactDetails.put("phoneNo", phoneNo);
	
	contactDetails.put("mobileContactMechId", mobileContactMechId);
	contactDetails.put("mobileNo", mobileNo);

}  catch(GenericServiceException e){
    //Debug.logError(e, module);
    //System.out.println("GenericServiceException e -> " + e);
    e.printStackTrace();
}  catch(GenericEntityException gee) {
    //Debug.logError(gee, module);
    //System.out.println("GenericServiceException gee -> " + gee);
    gee.printStackTrace();
}

return contactDetails;