import org.ofbiz.entity.*;
import org.ofbiz.common.*;
import java.util.*;
import javolution.util.*;
import org.ofbiz.service.*;
import org.ofbiz.base.util.*;

String firstName = parameters.firstName;

String emailContactMechId = parameters.emailContactMechId;
String emailId = parameters.emailId;

String addressContactMechId = parameters.addressContactMechId;
String countryGeoId = parameters.countryGeoId;
String stateProvinceGeoId = parameters.stateProvinceGeoId;

String mobileContactMechId = parameters.mobileContactMechId;
String mobileNo = parameters.mobileNo;

String phoneContactMechId = parameters.phoneContactMechId;
String phoneNo = parameters.phoneNo;

//GenericValue userLogin = context.userLogin;

//not getting the userLogin from context as user is not logged in
GenericValue userLogin = delegator.findOne("UserLogin", UtilMisc.toMap("userLoginId", "DemoCustomer"), false);
System.err.println("userLogin -> " + userLogin);

GenericValue systemLogin = delegator.findOne("UserLogin", UtilMisc.toMap("userLoginId", "system"), false);

Map<String, String> saveContactDetails = FastMap.newInstance();

if(userLogin != null) {

	//String partyId = userLogin.partyId;
	String partyId = "DemoCustomer";
	System.err.println("userLogin.partyId -> " + partyId);

	try {

		//start - update personal details
		Map resultUpdatePerson = dispatcher.runSync("updatePerson", 
				UtilMisc.toMap("firstName", firstName, "lastName", "check this", "userLogin", userLogin)
		);

		if(ServiceUtil.isSuccess(resultUpdatePerson)) {
			saveContactDetails.put("personalDetailsUpdate", "success");
		} else {
			saveContactDetails.put("personalDetailsUpdate", "error");
		}
		//end - update personal details
		
		
		//start - update email id
		if(UtilValidate.isNotEmpty(emailContactMechId)) {
			
			Map resultUpdatePartyEmail = dispatcher.runSync("updatePartyEmailAddress", UtilMisc.toMap("contactMechId", emailContactMechId, "emailAddress", emailId, "userLogin", userLogin));
			if(UtilValidate.isNotEmpty(resultUpdatePartyEmail)) {
				emailContactMechId = resultUpdatePartyEmail.get("contactMechId");
			}

			if(ServiceUtil.isSuccess(resultUpdatePartyEmail)) {
				saveContactDetails.put("emailUpdate","success");
				saveContactDetails.put("emailContactMechId", emailContactMechId); 
			} else {
				saveContactDetails.put("emailUpdate","error");
			}
		}
		//end - update email id
		
		//start - update postal address
		String address1 = null;
		String city = null;
		String postalCode = null;

		Map postalAddress = dispatcher.runSync("getPartyPostalAddress", 
            					UtilMisc.toMap("partyId", partyId, "contactMechPurposeTypeId", "GENERAL_LOCATION", "userLogin", userLogin));
		if(!ServiceUtil.isError(postalAddress)) {

			address1 = postalAddress.get("address1");
			city = postalAddress.get("city");
			postalCode = postalAddress.get("postalCode");
		}

		Map uPostalAddress = dispatcher.runSync("updatePartyPostalAddress", 
        
				UtilMisc.toMap(
								"contactMechId", addressContactMechId,
								"address1", address1,
								"city", city,
								"postalCode", postalCode,
								"stateProvinceGeoId", stateProvinceGeoId,
								"countryGeoId", countryGeoId,
								"userLogin", userLogin
					));
		
		if(UtilValidate.isNotEmpty(uPostalAddress)) {
			addressContactMechId = uPostalAddress.get("contactMechId");
		}
		
		if(ServiceUtil.isSuccess(uPostalAddress)) {
			saveContactDetails.put("addressUpdate","success");
			saveContactDetails.put("addressContactMechId", addressContactMechId);
		} else {
			saveContactDetails.put("addressUpdate","error");
		}
		//end - update postal address
		
		
		//start - update phone/mobile no.
		
		//start - phone
		if(UtilValidate.isNotEmpty(phoneContactMechId)) {
			
			Map primaryPhone = dispatcher.runSync("updatePartyTelecomNumber", 
					UtilMisc.toMap("contactMechId", phoneContactMechId,
								"contactNumber", phoneNo,
								"userLogin", userLogin
					));

			if(UtilValidate.isNotEmpty(primaryPhone)) {
				phoneContactMechId = primaryPhone.get("contactMechId");
			}
			
			if(ServiceUtil.isSuccess(primaryPhone)) {
				saveContactDetails.put("phoneUpdate","success");
				saveContactDetails.put("phoneContactMechId", phoneContactMechId);
			} else {
				saveContactDetails.put("phoneUpdate","error");
			}
		}
		

		if(UtilValidate.isNotEmpty(mobileContactMechId)) {
			
			Map mobilePhone = dispatcher.runSync("updatePartyTelecomNumber", 
					UtilMisc.toMap(
							"contactMechId", mobileContactMechId,
							"contactNumber", mobileNo,
							"userLogin", userLogin
							));

			if(UtilValidate.isNotEmpty(mobilePhone)) {
				mobileContactMechId = mobilePhone.get("contactMechId");
			}
			
			if(ServiceUtil.isSuccess(mobilePhone)) {
				saveContactDetails.put("mobileUpdate","success");
				saveContactDetails.put("mobileContactMechId", mobileContactMechId);
			} else {
				saveContactDetails.put("mobileUpdate","error");
			}
		}
		//end - update phone/mobile no.
		
	}  catch(GenericServiceException e){
	    //Debug.logError(e, module);
	    //System.out.println("GenericServiceException e -> " + e);
	    e.printStackTrace();
	}  catch(GenericEntityException gee) {
	    //Debug.logError(gee, module);
	    //System.out.println("GenericServiceException gee -> " + gee);
	    gee.printStackTrace();
	}
}

return saveContactDetails;