import org.ofbiz.entity.*;
import org.ofbiz.common.*;
import java.util.*;
import javolution.util.*;
import org.ofbiz.service.*;
import org.ofbiz.base.util.*;
import com.legeriti.ofbizify.gwt.gwtrpc.util.GwtRpcPayloadUtil;

System.err.println("####### GetUserDetails.groovy invoked ##############");
System.err.println("parameters -> " + parameters);

List<GenericValue> users = null;  

try {

	//fields = new HashSet(["userId", "firstName", "lastName", "address", "lastUpdatedStamp"]);
	//fields
	users = delegator.findList("OfbizifyExampleUsers", null, null, null, null, true );
	System.err.println("users -> " + users + "\n");

} catch(GenericEntityException gee) {
    gee.printStackTrace();
}

return GwtRpcPayloadUtil.returnSuccessWithPayload(users);