import org.ofbiz.entity.*;
import org.ofbiz.common.*;
import java.util.*;
import javolution.util.*;
import org.ofbiz.service.*;

cw = new CommonWorkers();
countryId = parameters.countryId;
states = cw.getAssociatedStateList(delegator, countryId);

return states;